import { ref } from 'vue'

export const workspaceList = ref([
  {
    id: 123548,
    name: 'One Piece'
  }
])
